<?php
require_once __DIR__ . '/config.php';

function ensureSchema($pdo) {
    static $migrated = false;
    if ($migrated) return;
    $migrated = true;

    try {
        // Create games table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `games` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `name` VARCHAR(100) NOT NULL,
            `slug` VARCHAR(50) NOT NULL UNIQUE,
            `icon` TEXT,
            `banner` TEXT,
            `description` TEXT,
            `is_active` TINYINT(1) DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Seed default games if empty
        $stmt = $pdo->query("SELECT COUNT(*) FROM `games`");
        if ($stmt->fetchColumn() == 0) {
            $pdo->exec("INSERT INTO `games` (`id`, `name`, `slug`, `icon`, `banner`, `description`, `is_active`) VALUES
                (1, 'Dream League Soccer (DLS)', 'dls', '⚽', 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800', 'Mobile football manager & arcade simulator. Compete in DLS custom leagues.', 1),
                (2, 'eFootball (PES)', 'efootball', '🎮', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800', 'Konamis ultra-realistic football action for mobile and console esports.', 1),
                (3, 'Call of Duty Mobile', 'codm', '🎯', 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800', 'Fast-paced FPS multiplayer and battle royale combat.', 1),
                (4, 'PUBG Mobile', 'pubg', '🪂', 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800', '100-player tactical battle royale survival shooter.', 1),
                (5, 'Free Fire', 'freefire', '🔥', 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800', '50-player intense 10-minute battle royale matches.', 1),
                (6, 'EA Sports FC / FIFA', 'eafc', '🏆', 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800', 'Ultimate team building and global competitive tournament football.', 1)
            ");
        }

        // Add missing columns to users
        $cols = $pdo->query("SHOW COLUMNS FROM `users`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('username', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `username` VARCHAR(100) NULL");
        if (!in_array('bio', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `bio` TEXT");
        if (!in_array('favorite_game', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `favorite_game` VARCHAR(50) DEFAULT 'DLS'");
        if (!in_array('can_create_forums', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `can_create_forums` TINYINT(1) DEFAULT 0");
        if (!in_array('last_seen', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `last_seen` TIMESTAMP NULL DEFAULT NULL");
        if (!in_array('typing_to', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `typing_to` INT DEFAULT NULL");
        if (!in_array('typing_at', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `typing_at` TIMESTAMP NULL DEFAULT NULL");
        if (!in_array('twitter', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `twitter` VARCHAR(100) NULL DEFAULT NULL");
        if (!in_array('instagram', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `instagram` VARCHAR(100) NULL DEFAULT NULL");
        if (!in_array('tiktok', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `tiktok` VARCHAR(100) NULL DEFAULT NULL");
        if (!in_array('discord', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `discord` VARCHAR(100) NULL DEFAULT NULL");
        if (!in_array('youtube', $cols)) $pdo->exec("ALTER TABLE `users` ADD COLUMN `youtube` VARCHAR(100) NULL DEFAULT NULL");

        // Add tournament_type, status, current_round to tournaments
        $tournCols = $pdo->query("SHOW COLUMNS FROM `tournaments`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('tournament_type', $tournCols)) {
            try {
                $pdo->exec("ALTER TABLE `tournaments` ADD COLUMN `tournament_type` ENUM('league', 'knockout', 'group_knockout') DEFAULT 'knockout'");
            } catch (Exception $e) {}
        }
        if (!in_array('status', $tournCols)) {
            try {
                $pdo->exec("ALTER TABLE `tournaments` ADD COLUMN `status` ENUM('draft', 'group_stage', 'knockout_stage', 'completed') DEFAULT 'draft'");
            } catch (Exception $e) {}
        }
        if (!in_array('current_round', $tournCols)) {
            try {
                $pdo->exec("ALTER TABLE `tournaments` ADD COLUMN `current_round` VARCHAR(50) DEFAULT NULL");
            } catch (Exception $e) {}
        }

        // Add bracket fields to fixtures
        $fixCols = $pdo->query("SHOW COLUMNS FROM `fixtures`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('stage', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `stage` VARCHAR(50) DEFAULT 'GROUP_STAGE'");
            } catch (Exception $e) {}
        }
        if (!in_array('group_name', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `group_name` VARCHAR(50) DEFAULT NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('bracket_position', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `bracket_position` INT DEFAULT NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('next_fixture_id', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `next_fixture_id` INT DEFAULT NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('winner_slot', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `winner_slot` ENUM('home', 'away') DEFAULT NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('score_edit_count', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `score_edit_count` TINYINT DEFAULT 0");
            } catch (Exception $e) {}
        }
        if (!in_array('score_submitted_at', $fixCols)) {
            try {
                $pdo->exec("ALTER TABLE `fixtures` ADD COLUMN `score_submitted_at` TIMESTAMP NULL DEFAULT NULL");
            } catch (Exception $e) {}
        }

        // Create tournament_standings table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `tournament_standings` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `tourn_id` INT NOT NULL,
            `team_name` VARCHAR(100) NOT NULL,
            `group_name` VARCHAR(50) DEFAULT NULL,
            `played` INT DEFAULT 0,
            `wins` INT DEFAULT 0,
            `draws` INT DEFAULT 0,
            `losses` INT DEFAULT 0,
            `goals_for` INT DEFAULT 0,
            `goals_against` INT DEFAULT 0,
            `goal_difference` INT GENERATED ALWAYS AS (goals_for - goals_against) STORED,
            `points` INT GENERATED ALWAYS AS (wins * 3 + draws * 1) STORED,
            `qualified_to_knockout` TINYINT(1) DEFAULT 0,
            `position_in_knockout` INT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY `tournament_team_group` (`tourn_id`, `team_name`, `group_name`),
            FOREIGN KEY (`tourn_id`) REFERENCES `tournaments`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Create followers table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `followers` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `follower_id` INT NOT NULL,
            `following_id` INT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `follower_following_unique` (`follower_id`, `following_id`),
            FOREIGN KEY (`follower_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
            FOREIGN KEY (`following_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Add is_read, read_at, reply_to_id to messages
        $msgCols = $pdo->query("SHOW COLUMNS FROM `messages`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('is_read', $msgCols)) {
            try {
                $pdo->exec("ALTER TABLE `messages` ADD COLUMN `is_read` TINYINT(1) DEFAULT 0");
            } catch (Exception $e) {}
        }
        if (!in_array('read_at', $msgCols)) {
            try {
                $pdo->exec("ALTER TABLE `messages` ADD COLUMN `read_at` TIMESTAMP NULL DEFAULT NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('reply_to_id', $msgCols)) {
            try {
                $pdo->exec("ALTER TABLE `messages` ADD COLUMN `reply_to_id` INT NULL DEFAULT NULL");
            } catch (Exception $e) {}
            try {
                $pdo->exec("ALTER TABLE `messages` ADD CONSTRAINT `fk_reply_to` FOREIGN KEY (`reply_to_id`) REFERENCES `messages`(`id`) ON DELETE SET NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('image_url', $msgCols)) {
            try {
                $pdo->exec("ALTER TABLE `messages` ADD COLUMN `image_url` VARCHAR(2048) NULL DEFAULT NULL");
            } catch (Exception $e) {}
        }

        // Create forums table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `forums` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `game_id` INT DEFAULT NULL,
            `title` VARCHAR(200) NOT NULL,
            `description` TEXT,
            `created_by` INT NOT NULL,
            `is_pinned` TINYINT(1) DEFAULT 0,
            `is_locked` TINYINT(1) DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Create forum_posts table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `forum_posts` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `forum_id` INT NOT NULL,
            `user_id` INT NOT NULL,
            `content` TEXT NOT NULL,
            `reply_to_id` INT DEFAULT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NULL DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Migrate reply_to_id onto existing forum_posts tables
        $fpCols = $pdo->query("SHOW COLUMNS FROM `forum_posts`")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('reply_to_id', $fpCols)) {
            try {
                $pdo->exec("ALTER TABLE `forum_posts` ADD COLUMN `reply_to_id` INT DEFAULT NULL");
            } catch (Exception $e) {}
        }
        if (!in_array('image_url', $fpCols)) {
            try {
                $pdo->exec("ALTER TABLE `forum_posts` ADD COLUMN `image_url` VARCHAR(2048) NULL DEFAULT NULL");
            } catch (Exception $e) {}
        }

        // Create forum_post_likes table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `forum_post_likes` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `post_id` INT NOT NULL,
            `user_id` INT NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `unique_post_user_like` (`post_id`, `user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Create forum_post_reactions table
        $pdo->exec("CREATE TABLE IF NOT EXISTS `forum_post_reactions` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `post_id` INT NOT NULL,
            `user_id` INT NOT NULL,
            `reaction` VARCHAR(10) NOT NULL,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `unique_post_user_reaction` (`post_id`, `user_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Seed default forums if empty
        $stmtF = $pdo->query("SELECT COUNT(*) FROM `forums`");
        if ($stmtF->fetchColumn() == 0) {
            $pdo->exec("INSERT INTO `forums` (`id`, `game_id`, `title`, `description`, `created_by`, `is_pinned`) VALUES
                (1, NULL, '🌐 Welcome & General Community Lounge', 'Official welcome lounge for all GameVerse players. Introduce yourself and meet fellow gamers!', 1, 1),
                (2, 1, '⚽ DLS Season 26 Tactics & Transfer Discussion', 'Share your dream team formations, player skill upgrades, and kit codes.', 1, 1),
                (3, 3, '🎯 CoD Mobile Loadouts & Squad Recruitment', 'Discuss top weapon builds, gunsmith setups, and form tournament squads.', 1, 0)
            ");
        }

    } catch (Exception $e) {
        // Silently skip schema errors if DB is constrained or already migrated
    }
}

function getPDO() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            ensureSchema($pdo);
        } catch (PDOException $e) {
            jsonResponse(['error' => 'Database connection failed: ' . $e->getMessage()], 500);
        }
    }
    return $pdo;
}

function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

function getJsonInput() {
    $rawInput = file_get_contents('php://input');
    return json_decode($rawInput, true) ?? [];
}